document.documentElement.scrollTop

window.onscroll = function (){
    if (document.documentElement.scrollTop>100){

        document.getElementById('nav').classList.add('navbar1');


    }else{
        document.getElementById('nav').classList.remove('navbar1');
    }

}

let btn = document.querySelector('#close-btn')
btn.addEventListener('click', closeBottomStrip)

function closeBottomStrip(){
    let overlay = document.querySelector('#overlay')
    overlay.style.display = 'none'


}



setTimeout(function (){
    document.querySelector('#overlay').style.display = 'block'
},3000)


