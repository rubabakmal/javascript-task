let table = prompt('Enter a Number');
let i = 0;

for (i=0; i<=10; i++){
   document.write(table + "*" + i + "=" + i*table +'<br>' )
}