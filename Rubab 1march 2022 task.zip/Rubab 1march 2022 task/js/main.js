
document.documentElement.scrollTop

window.onscroll = function (){
    if (document.documentElement.scrollTop>100){

        document.getElementById('nav').classList.add('navbar1');
    }else{
        document.getElementById('nav').classList.remove('navbar1');
    }

}

