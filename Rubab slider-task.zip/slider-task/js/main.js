function first () {
    document.getElementById("slider").src="img/testimonials-2.jpg";
}
function second () {
    document.getElementById("slider").src="img/testimonials-3.jpg";
}
function third () {
    document.getElementById("slider").src="img/testimonials-4.jpg";
}



setInterval(first,2000);
setInterval(second,3000);
setInterval(third,5000);

