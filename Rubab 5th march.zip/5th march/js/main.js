document.documentElement.scrollTop

window.onscroll = function () {
    if (document.documentElement.scrollTop > 50) {

        document.getElementById('nav').classList.add('navbar1');

    } else {
        document.getElementById('nav').classList.remove('navbar1');
    }


    if (document.documentElement.scrollTop>200){

        document.querySelector('#overlay').style.display = 'block'
    }else{
        document.querySelector('#overlay').style.display = 'none'
    }


}


let btn = document.querySelector('#close-btn')
btn.addEventListener('click', closeBottomStrip)

function closeBottomStrip(){
    let overlay = document.querySelector('#overlay')
    overlay.style.display = 'none'


}


setTimeout(function (){
    document.querySelector('#overlay').style.display = 'block'
},3000)


setTimeout(function (){
    document.querySelector('#overlay').style.display = 'none'
},6000)