
let btn = document.querySelector('#btn')
btn.addEventListener('click', model)

function model(){
  let search = document.querySelector('#model')

   search.style.display = 'block';


}


let searchBtn = document.getElementById('btn-search')
searchBtn.addEventListener('click', function (){
   alert();
})




let btnIcons = document.getElementById('btn-icons')
btnIcons.addEventListener('mouseover' , iconOne)

function iconOne(){
let socialIcons = document.getElementById('icons')

    socialIcons.style.display = 'block';

}




let fbIcon = document.getElementById('icon-fb')
fbIcon.addEventListener('mouseover' , facebook)

function facebook(){

       fbIcon.classList.add('fb');


}



let watsappIcon = document.getElementById('icon-whatsapp')
watsappIcon.addEventListener('mouseover' , watsapp)

function watsapp(){

    watsappIcon.classList.add('watsapp');


}



