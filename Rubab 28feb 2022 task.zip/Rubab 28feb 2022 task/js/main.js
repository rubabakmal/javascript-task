let img = document.getElementById('img')
let next = document.getElementById('btn-next')
let pre = document.getElementById('btn-pre')


let w = img.getAttribute('src');


v = 'img/img1.jfif' ;
w = 'img/img2.jfif ';

next.addEventListener("click", function (){

   img.setAttribute('src',w)

})


pre.addEventListener("click", function (){

   img.setAttribute('src',v)

})